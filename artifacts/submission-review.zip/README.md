# Collusion evidence study

Open `Run Atlas.html` locally to inspect the source evidence and evaluations. The `paper/` folder contains the manuscript source and bibliography; `real-evaluation/` contains the fixed protocol, references and results.

Reference labels are provisional AI-assisted source audits, not independent human gold labels.

Code and attribution: https://github.com/Dexter-Yao/collusion-evidence-pipeline
